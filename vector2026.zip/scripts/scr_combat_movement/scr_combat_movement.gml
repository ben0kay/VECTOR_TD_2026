/// @description Advanced enemy combat movement and temporary player targeting.


/// @description Moves one angle toward another without wrapping incorrectly.

function scr_enemy_angle_approach(
    _current,
    _target,
    _amount
)
{
    var _difference =
        angle_difference(
            _target,
            _current
        );

    return (
        _current
        + clamp(
            _difference,
            -_amount,
            _amount
        )
        + 360
    ) mod 360;
}




/// @description Returns target-edge distance from an arbitrary position.

function scr_enemy_target_edge_distance_at(
    _enemy,
    _target,
    _world_x,
    _world_y
)
{
    if (!instance_exists(_enemy))
        return infinity;

    if (!instance_exists(_target))
        return infinity;


    if (
        _target.object_index == o_building_par
        || object_is_ancestor(
            _target.object_index,
            o_building_par
        )
    )
    {
        var _cell_size =
            global.vtd_level.map.cell_size;

        var _half_width =
            _target.footprint.width_cells
            * _cell_size
            * 0.5;

        var _half_height =
            _target.footprint.height_cells
            * _cell_size
            * 0.5;

        var _closest_x =
            clamp(
                _world_x,
                _target.x - _half_width,
                _target.x + _half_width
            );

        var _closest_y =
            clamp(
                _world_y,
                _target.y - _half_height,
                _target.y + _half_height
            );

        return max(
            0,

            point_distance(
                _world_x,
                _world_y,
                _closest_x,
                _closest_y
            )
            - _enemy.visual.radius
            - (_cell_size * 0.25)
        );
    }


    var _target_radius = 0;


    if (
        variable_instance_exists(
            _target,
            "visual"
        )
        && is_struct(_target.visual)
        && variable_struct_exists(
            _target.visual,
            "radius"
        )
    )
    {
        _target_radius =
            _target.visual.radius;
    }


    return max(
        0,

        point_distance(
            _world_x,
            _world_y,
            _target.x,
            _target.y
        )
        - _enemy.visual.radius
        - _target_radius
    );
}


/// @description Begins a combat anchor at the enemy's current position.

function scr_enemy_combat_anchor_begin(
    _enemy,
    _target
)
{
    if (!instance_exists(_enemy))
        return false;

    if (!instance_exists(_target))
        return false;


    var _anchor =
        _enemy.combat_movement.anchor;

    var _destination =
        _enemy.combat_movement.destination;

    var _reposition =
        _enemy.combat_movement.reposition;

    var _data =
        _enemy.combat_movement.data;


    _anchor.x = _enemy.x;
    _anchor.y = _enemy.y;

    _anchor.valid = true;
    _anchor.target = _target;

    _anchor.navigation_revision =
        global.vtd_level.navigation.revision;


    _destination.x = _enemy.x;
    _destination.y = _enemy.y;
    _destination.active = false;


    _reposition.remaining =
        random_range(
            _data.reposition.interval_minimum,
            _data.reposition.interval_maximum
        );


    return true;
}


/// @description Returns whether a short local movement segment remains clear.

function scr_enemy_combat_segment_clear(
    _enemy,
    _start_x,
    _start_y,
    _end_x,
    _end_y
)
{
    if (!instance_exists(_enemy))
        return false;


    var _distance =
        point_distance(
            _start_x,
            _start_y,
            _end_x,
            _end_y
        );

    var _sample_distance =
        max(
            4,
            _enemy.visual.radius * 0.4
        );

    var _steps =
        max(
            1,
            ceil(
                _distance
                / _sample_distance
            )
        );


    for (var i = 1; i <= _steps; ++i)
    {
        var _amount =
            i / _steps;

        var _check_x =
            lerp(
                _start_x,
                _end_x,
                _amount
            );

        var _check_y =
            lerp(
                _start_y,
                _end_y,
                _amount
            );


        if (
            scr_world_circle_gameplay_solid(
                _check_x,
                _check_y,
                _enemy.visual.radius,
                true
            )
        )
        {
            return false;
        }
    }


    return true;
}


/// @description Returns whether a local combat destination is usable.

function scr_enemy_combat_destination_valid(
    _enemy,
    _target,
    _world_x,
    _world_y
)
{
    if (!instance_exists(_enemy))
        return false;

    if (!instance_exists(_target))
        return false;


    var _data =
        _enemy.combat_movement.data;

    var _reposition =
        _data.reposition;


    if (
        _world_x < _enemy.visual.radius
        || _world_x
            > room_width
            - _enemy.visual.radius

        || _world_y < _enemy.visual.radius
        || _world_y
            > room_height
            - _enemy.visual.radius
    )
    {
        return false;
    }


    if (
        point_distance(
            _enemy.combat_movement.anchor.x,
            _enemy.combat_movement.anchor.y,
            _world_x,
            _world_y
        )
        > _data.anchor_radius
    )
    {
        return false;
    }


    var _target_distance =
        scr_enemy_target_edge_distance_at(
            _enemy,
            _target,
            _world_x,
            _world_y
        );


    if (
        _target_distance < _data.minimum_range
        || _target_distance > _data.maximum_range
    )
    {
        return false;
    }


    if (
        scr_world_circle_gameplay_solid(
            _world_x,
            _world_y,
            _enemy.visual.radius,
            true
        )
    )
    {
        return false;
    }


    if (
        !scr_enemy_combat_segment_clear(
            _enemy,
            _enemy.x,
            _enemy.y,
            _world_x,
            _world_y
        )
    )
    {
        return false;
    }


    if (
        _reposition.require_line_of_sight
        && scr_world_line_blocked_by_dead(
            _world_x,
            _world_y,
            _target.x,
            _target.y
        )
    )
    {
        return false;
    }


    return true;
}


/// @description Attempts to choose a new point inside the combat anchor.

function scr_enemy_combat_destination_choose(
    _enemy,
    _target
)
{
    if (!instance_exists(_enemy))
        return false;

    if (!instance_exists(_target))
        return false;


    var _runtime =
        _enemy.combat_movement;

    var _data =
        _runtime.data;

    var _reposition =
        _data.reposition;

    var _attempts =
        max(
            1,
            floor(
                _reposition.candidate_attempts
            )
        );


    repeat (_attempts)
    {
        var _direction =
            random(360);

        var _distance =
            random_range(
                _reposition.distance_minimum,
                _reposition.distance_maximum
            );

        var _candidate_x =
            _runtime.anchor.x
            + lengthdir_x(
                _distance,
                _direction
            );

        var _candidate_y =
            _runtime.anchor.y
            + lengthdir_y(
                _distance,
                _direction
            );


        if (
            !scr_enemy_combat_destination_valid(
                _enemy,
                _target,
                _candidate_x,
                _candidate_y
            )
        )
        {
            continue;
        }


        _runtime.destination.x =
            _candidate_x;

        _runtime.destination.y =
            _candidate_y;

        _runtime.destination.active =
            true;


        return true;
    }


    _runtime.destination.active =
        false;

    return false;
}


/// @description Moves an anchored enemy toward its local destination.

function scr_enemy_combat_destination_move(_enemy)
{
    if (!instance_exists(_enemy))
        return false;


    var _runtime =
        _enemy.combat_movement;

    var _destination =
        _runtime.destination;

    var _data =
        _runtime.data;


    if (!_destination.active)
        return true;


    var _distance =
        point_distance(
            _enemy.x,
            _enemy.y,
            _destination.x,
            _destination.y
        );


    if (
        _distance
        <= _data.reposition.arrival_tolerance
    )
    {
        _enemy.x =
            _destination.x;

        _enemy.y =
            _destination.y;

        _destination.active =
            false;

        return true;
    }


    var _move_direction =
        point_direction(
            _enemy.x,
            _enemy.y,
            _destination.x,
            _destination.y
        );

    var _move_amount =
        min(
            _distance,

            _enemy.movement.speed
            * _data.speed_multiplier
        );

    var _next_x =
        _enemy.x
        + lengthdir_x(
            _move_amount,
            _move_direction
        );

    var _next_y =
        _enemy.y
        + lengthdir_y(
            _move_amount,
            _move_direction
        );


    if (
        scr_world_circle_gameplay_solid(
            _next_x,
            _next_y,
            _enemy.visual.radius,
            true
        )
    )
    {
        _destination.active =
            false;

        return false;
    }


    _enemy.x = _next_x;
    _enemy.y = _next_y;


    _enemy.visual.hull_angle =
        scr_enemy_angle_approach(
            _enemy.visual.hull_angle,
            _move_direction,
            _data.hull_turn_speed
        );

    _enemy.visual.draw_angle =
        _enemy.visual.hull_angle;


    return true;
}


/// @description Processes one enemy's reusable combat movement.

function scr_enemy_combat_movement_update(
    _enemy,
    _target
)
{
    if (!instance_exists(_enemy))
        return false;

    if (!instance_exists(_target))
        return false;


    var _runtime =
        _enemy.combat_movement;

    var _data =
        _runtime.data;


    if (
        _data.type
        != EnemyCombatMovement.ANCHOR_ROAM
    )
    {
        return true;
    }


    if (
        !_runtime.anchor.valid
        || _runtime.anchor.target != _target
    )
    {
        scr_enemy_combat_anchor_begin(
            _enemy,
            _target
        );
    }


    // Existing construction may invalidate the local destination.

    if (
        _runtime.anchor.navigation_revision
        != global.vtd_level.navigation.revision
    )
    {
        _runtime.anchor.navigation_revision =
            global.vtd_level.navigation.revision;

        _runtime.destination.active =
            false;

        _runtime.reposition.remaining =
            random_range(
                0.25,
                0.75
            );
    }


    var _fps =
        max(
            1,
            game_get_speed(gamespeed_fps)
        );


    _runtime.reposition.remaining =
        max(
            0,
            _runtime.reposition.remaining
            - (1 / _fps)
        );


    if (
        !_runtime.destination.active
        && _runtime.reposition.remaining <= 0
    )
    {
        _runtime.reposition.remaining =
            random_range(
                _data.reposition.interval_minimum,
                _data.reposition.interval_maximum
            );


        if (
            _data.reposition.enabled
            && random(1)
                <= _data.reposition.chance
        )
        {
            scr_enemy_combat_destination_choose(
                _enemy,
                _target
            );
        }
    }


    return scr_enemy_combat_destination_move(
        _enemy
    );
}

/// @description Assigns a new strategic target and resets target-specific decisions.

function scr_enemy_strategic_target_set(_enemy, _target)
{
    if (!instance_exists(_enemy))
        return false;

    var _old_target =
        _enemy.targeting.strategic;

    if (_old_target == _target)
        return false;


    _enemy.targeting.strategic =
        _target;


    // A new strategic target permits one new player roll.

    if (variable_struct_exists(_enemy.targeting, "player"))
    {
        var _player_runtime =
            _enemy.targeting.player;

        _player_runtime.roll.strategic_target =
            _target;

        _player_runtime.roll.completed =
            false;

        _player_runtime.roll.succeeded =
            false;
    }


    // Do not interrupt active player aggro or an active breach target.

    if (
        !_enemy.targeting.player.active
        && !instance_exists(_enemy.targeting.breach)
    )
    {
        _enemy.targeting.target =
            _target;
    }


    return true;
}

/// @description Periodically switches to a meaningfully closer nearby building.

function scr_enemy_strategic_retarget_update(
    _enemy,
    _immediate = false
)
{
    if (!instance_exists(_enemy))
        return false;


    var _runtime =
        _enemy.targeting.strategic_retarget;

    var _data =
        _runtime.data;


    if (!_data.enabled)
        return true;


    // Do not change the strategic objective while temporarily pursuing
    // the player or attacking a breach target.

    if (
        _enemy.targeting.player.active
        || instance_exists(_enemy.targeting.breach)
    )
    {
        return true;
    }


    var _fps =
        max(
            1,
            game_get_speed(gamespeed_fps)
        );


    _runtime.remaining =
        max(
            0,
            _runtime.remaining - (1 / _fps)
        );


    if (!_immediate && _runtime.remaining > 0)
        return true;


    _runtime.remaining =
        random_range(
            _data.interval_minimum,
            _data.interval_maximum
        );


    var _current =
        _enemy.targeting.strategic;


    // Only inspect buildings inside this enemy's local scan circle.
    // Global recovery remains the responsibility of scr_enemy_target_acquire()
    // when the enemy genuinely has no valid strategic target.

    var _candidate =
        scr_enemy_closest_building_get(
            _enemy,
            _data.scan_range
        );


    // Nothing nearby means the enemy continues toward its cached objective.
    // Do not trigger an unnecessary full-map search here.

    if (!instance_exists(_candidate))
        return true;


    // An invalid cached target can be replaced immediately by the nearby
    // candidate. If there is no nearby candidate, scr_enemy_update() will
    // perform the ordinary global target recovery.

    if (!instance_exists(_current))
    {
        scr_enemy_strategic_target_set(
            _enemy,
            _candidate
        );


        _enemy.EnemyState =
            EnemyState.MOVING;


        scr_navigation_enemy_repath_request(
            _enemy,
            true
        );


        return true;
    }


    if (_candidate == _current)
        return true;


    var _current_distance =
        point_distance(
            _enemy.x,
            _enemy.y,
            _current.x,
            _current.y
        );

    var _candidate_distance =
        point_distance(
            _enemy.x,
            _enemy.y,
            _candidate.x,
            _candidate.y
        );


    var _fixed_advantage =
        _candidate_distance
        <= _current_distance
        - _data.minimum_distance_advantage;

    var _ratio_advantage =
        _candidate_distance
        <= _current_distance
        * _data.switch_ratio;


    // Avoid target jitter. The nearby building must be substantially closer.

    if (!_fixed_advantage && !_ratio_advantage)
        return true;


    scr_enemy_strategic_target_set(
        _enemy,
        _candidate
    );


    _enemy.EnemyState =
        EnemyState.MOVING;


    scr_navigation_enemy_repath_request(
        _enemy,
        true
    );


    return true;
}

/// @description Processes a ranged enemy seeking a clear standoff position.

function scr_enemy_standoff_update(_enemy)
{
    if (!instance_exists(_enemy))
        return false;


    var _target =
        _enemy.targeting.target;

    if (!instance_exists(_target))
        return true;


    var _data =
        _enemy.combat_movement.data;

    var _edge_distance =
        scr_enemy_target_edge_distance(
            _enemy,
            _target
        );

    var _line_clear =
        !_data.requires_line_of_sight
        || !scr_world_line_blocked_by_dead(
            _enemy.x,
            _enemy.y,
            _target.x,
            _target.y
        );


    switch (_enemy.EnemyState)
    {
        case EnemyState.SPAWNING:
        {
            _enemy.EnemyState =
                EnemyState.MOVING;

            scr_navigation_enemy_repath_request(
                _enemy,
                true
            );
        }
        break;


        case EnemyState.MOVING:
        {
            if (
                _edge_distance
                <= _data.preferred_range
                && _edge_distance
                >= _data.minimum_range
                && _line_clear
            )
            {
                scr_navigation_enemy_stop(
                    _enemy
                );

                _enemy.EnemyState =
                    EnemyState.ATTACKING;

                break;
            }


            // Continue around dead terrain until a valid firing lane appears.

            scr_navigation_enemy_update(
                _enemy
            );
        }
        break;


        case EnemyState.ATTACKING:
        {
            _enemy.visual.draw_angle =
                point_direction(
                    _enemy.x,
                    _enemy.y,
                    _target.x,
                    _target.y
                );


            _line_clear =
                !_data.requires_line_of_sight
                || !scr_world_line_blocked_by_dead(
                    _enemy.x,
                    _enemy.y,
                    _target.x,
                    _target.y
                );


            if (
                _edge_distance
                > _data.maximum_range
                || !_line_clear
            )
            {
                _enemy.EnemyState =
                    EnemyState.MOVING;

                scr_navigation_enemy_repath_request(
                    _enemy,
                    true
                );

                break;
            }


            if (_enemy.attack.cooldown.remaining <= 0)
            {
                scr_enemy_attack(
                    _enemy
                );
            }
        }
        break;


        case EnemyState.STUNNED:
        case EnemyState.DEAD:
        {
            scr_navigation_enemy_stop(
                _enemy
            );
        }
        break;
    }


    return true;
}

/// @description Creates a reusable cached combat line-of-sight runtime.

function scr_combat_line_of_sight_cache_create(
    _interval_minimum = 8,
    _interval_maximum = 15,
    _movement_refresh_distance = 32,
    _blocked_function = scr_world_line_blocked_by_dead
)
{
    return
    {
        clear: false,

        timer: 0,

        interval_minimum:
            max(1, _interval_minimum),

        interval_maximum:
            max(
                _interval_minimum,
                _interval_maximum
            ),

        movement_refresh_distance:
            max(
                0,
                _movement_refresh_distance
            ),

        blocked_function:
            _blocked_function,

        target: noone,

        source_x: 0,
        source_y: 0,

        target_x: 0,
        target_y: 0,

        navigation_revision: -1,
        initialized: false
    };
}

/// @description Returns a cached combat line-of-sight result.

function scr_combat_line_of_sight_cache_update(
    _source,
    _target,
    _cache,
    _interval_multiplier = 1
)
{
    if (!instance_exists(_source))
        return false;

    if (!instance_exists(_target))
        return false;

    if (!is_struct(_cache))
        return false;


    _cache.timer--;


    var _distance =
        _cache.movement_refresh_distance;

    var _distance_squared =
        _distance * _distance;


    // ========================================================================
    // SOURCE MOVEMENT
    // ========================================================================

    var _source_move_x =
        _source.x
        - _cache.source_x;

    var _source_move_y =
        _source.y
        - _cache.source_y;

    var _source_moved =
        (
            (_source_move_x * _source_move_x)
            + (_source_move_y * _source_move_y)
        )
        >= _distance_squared;


    // ========================================================================
    // TARGET MOVEMENT
    // ========================================================================

    var _target_move_x =
        _target.x
        - _cache.target_x;

    var _target_move_y =
        _target.y
        - _cache.target_y;

    var _target_moved =
        (
            (_target_move_x * _target_move_x)
            + (_target_move_y * _target_move_y)
        )
        >= _distance_squared;


    // ========================================================================
    // WORLD REVISION
    // ========================================================================

    var _navigation_revision =
        global.vtd_level.navigation.revision;

    var _navigation_changed =
        _cache.navigation_revision
        != _navigation_revision;


    // ========================================================================
    // REFRESH DECISION
    // ========================================================================

    var _refresh =
        !_cache.initialized
        || _cache.timer <= 0
        || _cache.target != _target
        || _source_moved
        || _target_moved
        || _navigation_changed;


    if (!_refresh)
        return _cache.clear;


    // The configured function decides what blocks this particular beam.
    //
    // Current example:
    // scr_world_line_blocked_by_dead
    //
    // FUTURE:
    // scr_world_line_blocked_by_building
    // scr_world_line_blocked_by_any_solid
    // scr_world_line_blocked_by_shield

    var _blocked =
        _cache.blocked_function(
            _source.x,
            _source.y,
            _target.x,
            _target.y
        );


    _cache.clear =
        !_blocked;

    _cache.target =
        _target;

    _cache.source_x =
        _source.x;

    _cache.source_y =
        _source.y;

    _cache.target_x =
        _target.x;

    _cache.target_y =
        _target.y;

    _cache.navigation_revision =
        _navigation_revision;

    _cache.initialized =
        true;


    _cache.timer =
        irandom_range(
            _cache.interval_minimum,
            _cache.interval_maximum
        )
        * max(
            1,
            _interval_multiplier
        );


    return _cache.clear;
}