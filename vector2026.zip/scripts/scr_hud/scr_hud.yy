{
  "$GMScript":"v1",
  "%Name":"scr_hud",
  "isCompatibility":false,
  "isDnD":false,
  "name":"scr_hud",
  "parent":{
    "name":"hud scripts",
    "path":"folders/scripts/group1/hud scripts.yy",
  },
  "resourceType":"GMScript",
  "resourceVersion":"2.0",
}