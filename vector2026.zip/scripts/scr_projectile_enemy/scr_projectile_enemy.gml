/// @description Hostile projectile creation, collision, damage, and drawing.


/// @description Creates one hostile projectile on its owner's visual layer.

function scr_projectile_enemy_create(
    _owner,
    _world_x,
    _world_y,
    _draw_angle,
    _damage,
    _projectile_data
)
{
    if (!instance_exists(_owner))
        return noone;

    if (!is_struct(_projectile_data))
        return noone;


    var _impact = ProjectileImpact.DIRECT;
    var _damage_radius = 0;
    var _rocket = false;


    if (variable_struct_exists(_projectile_data, "impact"))
        _impact = _projectile_data.impact;

    if (variable_struct_exists(_projectile_data, "damage_radius"))
        _damage_radius = _projectile_data.damage_radius;

    if (variable_struct_exists(_projectile_data, "rocket"))
        _rocket = _projectile_data.rocket;


    return instance_create_layer(
        _world_x,
        _world_y,

        scr_layer_projectile_get(
            _owner.movement.layer
        ),

        o_projectile_enemy,
        {
            projectile_owner: _owner,
            projectile_damage: _damage,
            projectile_speed: _projectile_data.speed,
            projectile_lifetime: _projectile_data.lifetime_seconds,
            projectile_radius: _projectile_data.radius,
            projectile_color: _projectile_data.color,
            projectile_angle: _draw_angle,

            projectile_impact: _impact,
            projectile_damage_radius: _damage_radius,
            projectile_rocket: _rocket
        }
    );
}

/// @description Initializes one hostile projectile runtime.

function scr_projectile_enemy_initialize(_projectile)
{
    if (!instance_exists(_projectile))
        return false;


    _projectile.combat =
    {
        owner: _projectile.projectile_owner,
        damage: _projectile.projectile_damage,
        impact: _projectile.projectile_impact,
        damage_radius: max(0, _projectile.projectile_damage_radius)
    };


    _projectile.movement =
    {
        speed: _projectile.projectile_speed
    };


    _projectile.life =
    {
        remaining: _projectile.projectile_lifetime
    };


    _projectile.visual =
    {
        draw_angle: _projectile.projectile_angle,
        radius: _projectile.projectile_radius,
        color: _projectile.projectile_color,
        rocket: _projectile.projectile_rocket
    };


    return true;
}


/// @description Returns an approximate collision radius for a hostile target.

function scr_projectile_enemy_target_radius(_target)
{
    if (!instance_exists(_target))
        return 0;


    if (_target.object_index == o_cpu)
        return _target.visual.radius;


    if (_target.object_index == o_player)
        return _target.visual.radius;


    if (
        _target.object_index == o_building_par
        || object_is_ancestor(_target.object_index, o_building_par)
    )
    {
        var _cell_size = global.vtd_level.map.cell_size;
        var _width = _target.footprint.width_cells * _cell_size;
        var _height = _target.footprint.height_cells * _cell_size;

        return point_distance(0, 0, _width * 0.5, _height * 0.5);
    }


    return 0;
}


/// @description Considers one instance as the possible first projectile hit.

function scr_projectile_enemy_hit_consider(
    _projectile,
    _target,
    _start_x,
    _start_y,
    _end_x,
    _end_y,
    _result
)
{
    if (!instance_exists(_target))
        return _result;


    var _target_radius = scr_projectile_enemy_target_radius(_target);
    var _collision_radius = _target_radius + _projectile.visual.radius;

    var _distance_squared = scr_point_segment_distance_squared(
        _target.x,
        _target.y,
        _start_x,
        _start_y,
        _end_x,
        _end_y
    );


    if (_distance_squared > _collision_radius * _collision_radius)
        return _result;


    var _travel_distance = point_distance(
        _start_x,
        _start_y,
        _target.x,
        _target.y
    );


    if (_travel_distance < _result.distance)
    {
        _result.target = _target;
        _result.distance = _travel_distance;
    }


    return _result;
}


/// @description Finds the first CPU, player, or building crossed by a projectile.

function scr_projectile_enemy_hit_find(
    _projectile,
    _start_x,
    _start_y,
    _end_x,
    _end_y
)
{
    var _result =
    {
        target: noone,
        distance: infinity
    };


    _result = scr_projectile_enemy_hit_consider(
        _projectile,
        global.vtd_level.entities.cpu,
        _start_x,
        _start_y,
        _end_x,
        _end_y,
        _result
    );


    _result = scr_projectile_enemy_hit_consider(
        _projectile,
        global.vtd_level.entities.player,
        _start_x,
        _start_y,
        _end_x,
        _end_y,
        _result
    );


    var _building_count = instance_number(o_building_par);

    for (var i = 0; i < _building_count; ++i)
    {
        var _building = instance_find(o_building_par, i);

        if (!scr_enemy_building_target_valid(_building))
            continue;

        _result = scr_projectile_enemy_hit_consider(
            _projectile,
            _building,
            _start_x,
            _start_y,
            _end_x,
            _end_y,
            _result
        );
    }


    return _result.target;
}

/// @description Returns the squared distance from a point to a line segment.

function scr_point_segment_distance_squared(
    _point_x,
    _point_y,
    _start_x,
    _start_y,
    _end_x,
    _end_y
)
{
    var _segment_x =
        _end_x - _start_x;

    var _segment_y =
        _end_y - _start_y;

    var _length_squared =
        (_segment_x * _segment_x)
        + (_segment_y * _segment_y);


    // The segment has no length, so compare against its starting point.

    if (_length_squared <= 0)
    {
        var _difference_x =
            _point_x - _start_x;

        var _difference_y =
            _point_y - _start_y;


        return (
            (_difference_x * _difference_x)
            + (_difference_y * _difference_y)
        );
    }


    // Find the closest position along the segment.
    // Zero is the start and one is the end.

    var _amount =
        (
            ((_point_x - _start_x) * _segment_x)
            + ((_point_y - _start_y) * _segment_y)
        )
        / _length_squared;


    _amount =
        clamp(
            _amount,
            0,
            1
        );


    var _closest_x =
        _start_x
        + (_segment_x * _amount);

    var _closest_y =
        _start_y
        + (_segment_y * _amount);


    var _distance_x =
        _point_x - _closest_x;

    var _distance_y =
        _point_y - _closest_y;


    return (
        (_distance_x * _distance_x)
        + (_distance_y * _distance_y)
    );
}


/// @description Applies projectile damage according to the impacted object type.

function scr_projectile_enemy_damage_target(_projectile, _target)
{
    if (!instance_exists(_projectile))
        return false;

    if (!instance_exists(_target))
        return false;


    var _damage = scr_damage_create(
        _projectile.combat.damage,
        _projectile.combat.owner,
        DamageSource.ENEMY
    );


    if (_target.object_index == o_cpu)
        return scr_cpu_damage(_target, _damage.amount);


    if (_target.object_index == o_player)
        return scr_player_damage(_target, _damage);


    if (
        _target.object_index == o_building_par
        || object_is_ancestor(_target.object_index, o_building_par)
    )
    {
        return scr_building_damage(_target, _damage);
    }


    return false;
}

/// @description Moves one hostile projectile and resolves its first impact.

function scr_projectile_enemy_update(_projectile)
{
    if (!instance_exists(_projectile))
        return false;


    var _fps =
        max(
            1,
            game_get_speed(gamespeed_fps)
        );

    _projectile.life.remaining =
        max(
            0,
            _projectile.life.remaining
            - (1 / _fps)
        );


    if (_projectile.life.remaining <= 0)
    {
        instance_destroy(
            _projectile
        );

        return true;
    }


    var _start_x =
        _projectile.x;

    var _start_y =
        _projectile.y;

    var _end_x =
        _start_x
        + lengthdir_x(
            _projectile.movement.speed,
            _projectile.visual.draw_angle
        );

    var _end_y =
        _start_y
        + lengthdir_y(
            _projectile.movement.speed,
            _projectile.visual.draw_angle
        );


    // ========================================================================
    // PERMANENT TERRAIN
    // ========================================================================

    var _terrain_hit =
        scr_projectile_enemy_terrain_hit_get(
            _projectile,
            _start_x,
            _start_y,
            _end_x,
            _end_y
        );


    if (_terrain_hit.hit)
    {
        _projectile.x =
            _terrain_hit.x;

        _projectile.y =
            _terrain_hit.y;


        if (
            _projectile.combat.impact
            == ProjectileImpact.EXPLOSIVE
        )
        {
            scr_projectile_enemy_explosion_apply(
                _projectile
            );
        }


        instance_destroy(
            _projectile
        );

        return true;
    }


    // ========================================================================
    // PLAYER STRUCTURES
    // ========================================================================

    var _target =
        scr_projectile_enemy_hit_find(
            _projectile,
            _start_x,
            _start_y,
            _end_x,
            _end_y
        );


    if (instance_exists(_target))
    {
        _projectile.x =
            _end_x;

        _projectile.y =
            _end_y;


        switch (_projectile.combat.impact)
        {
            case ProjectileImpact.DIRECT:
            {
                scr_projectile_enemy_damage_target(
                    _projectile,
                    _target
                );
            }
            break;


            case ProjectileImpact.EXPLOSIVE:
            {
                scr_projectile_enemy_explosion_apply(
                    _projectile
                );
            }
            break;
        }


        instance_destroy(
            _projectile
        );

        return true;
    }


    _projectile.x =
        _end_x;

    _projectile.y =
        _end_y;


    return true;
}

/// @description Draws one hostile vector projectile.

function scr_projectile_enemy_draw(_projectile)
{
    if (!instance_exists(_projectile))
        return false;


    var _visual = _projectile.visual;
    var _angle = _visual.draw_angle;


    if (_visual.rocket)
    {
        var _pulse =
            0.6
            + dsin(
                (global.vtd.tick * 12)
                + real(_projectile.id)
            ) * 0.25;


        // Long exhaust trail.

        draw_set_alpha(_pulse);
        draw_set_color(c_yellow);

        draw_line_width(
            _projectile.x + lengthdir_x(10, _angle + 180),
            _projectile.y + lengthdir_y(10, _angle + 180),
            _projectile.x + lengthdir_x(28, _angle + 180),
            _projectile.y + lengthdir_y(28, _angle + 180),
            5
        );


        // Rotating diamond-shaped warhead.

        draw_set_alpha(1);
        draw_set_color(_visual.color);

        var _front_x =
            _projectile.x + lengthdir_x(13, _angle);

        var _front_y =
            _projectile.y + lengthdir_y(13, _angle);

        var _back_x =
            _projectile.x + lengthdir_x(10, _angle + 180);

        var _back_y =
            _projectile.y + lengthdir_y(10, _angle + 180);

        var _left_x =
            _projectile.x + lengthdir_x(7, _angle + 90);

        var _left_y =
            _projectile.y + lengthdir_y(7, _angle + 90);

        var _right_x =
            _projectile.x + lengthdir_x(7, _angle - 90);

        var _right_y =
            _projectile.y + lengthdir_y(7, _angle - 90);


        draw_line_width(_front_x, _front_y, _left_x, _left_y, 2);
        draw_line_width(_left_x, _left_y, _back_x, _back_y, 2);
        draw_line_width(_back_x, _back_y, _right_x, _right_y, 2);
        draw_line_width(_right_x, _right_y, _front_x, _front_y, 2);

        draw_circle(
            _projectile.x,
            _projectile.y,
            3,
            true
        );


        draw_set_alpha(1);
        draw_set_color(c_white);

        return true;
    }


    // Normal hostile projectile.

    var _trail_x =
        _projectile.x - lengthdir_x(12, _angle);

    var _trail_y =
        _projectile.y - lengthdir_y(12, _angle);


    draw_set_color(_visual.color);

    draw_line_width(
        _trail_x,
        _trail_y,
        _projectile.x,
        _projectile.y,
        3
    );

    draw_circle(
        _projectile.x,
        _projectile.y,
        _visual.radius,
        false
    );

    draw_set_color(c_white);

    return true;
}

/// @description Applies an enemy explosion to one possible target.

function scr_projectile_enemy_explosion_target(
    _projectile,
    _target,
    _world_x,
    _world_y,
    _radius
)
{
    if (!instance_exists(_target))
        return false;


    var _target_radius =
        scr_projectile_enemy_target_radius(_target);

    var _distance = point_distance(
        _world_x,
        _world_y,
        _target.x,
        _target.y
    );


    if (_distance > _radius + _target_radius)
        return false;


    var _damage = scr_damage_create(
        _projectile.combat.damage,
        _projectile.combat.owner,
        DamageSource.ENEMY,
        DamageType.EXPLOSIVE
    );


    if (_target.object_index == o_cpu)
        return scr_cpu_damage(_target, _damage.amount);


    if (_target.object_index == o_player)
        return scr_player_damage(_target, _damage);


    if (
        _target.object_index == o_building_par
        || object_is_ancestor(
            _target.object_index,
            o_building_par
        )
    )
    {
        return scr_building_damage(
            _target,
            _damage
        );
    }


    return false;
}

/// @description Applies one hostile explosive projectile blast.

function scr_projectile_enemy_explosion_apply(_projectile)
{
    if (!instance_exists(_projectile))
        return false;


    var _radius =
        _projectile.combat.damage_radius;

    if (_radius <= 0)
        return false;


    scr_projectile_enemy_explosion_target(
        _projectile,
        global.vtd_level.entities.cpu,
        _projectile.x,
        _projectile.y,
        _radius
    );


    scr_projectile_enemy_explosion_target(
        _projectile,
        global.vtd_level.entities.player,
        _projectile.x,
        _projectile.y,
        _radius
    );


    var _building_count =
        instance_number(o_building_par);


    for (var i = 0; i < _building_count; ++i)
    {
        var _building =
            instance_find(o_building_par, i);

        if (!scr_enemy_building_target_valid(_building))
            continue;


        scr_projectile_enemy_explosion_target(
            _projectile,
            _building,
            _projectile.x,
            _projectile.y,
            _radius
        );
    }


    scr_effect_shockwave_create(
        _projectile.x,
        _projectile.y,
        _radius,
        _projectile.visual.color,
        EnemyMovementLayer.GROUND
    );


    // FUTURE:
    // explosion particles
    // debris sparks
    // smoke trail termination
    // camera shake
    // explosion sound


    return true;
}

/// @description Finds the first permanent terrain collision along a projectile segment.

function scr_projectile_enemy_terrain_hit_get(
    _projectile,
    _start_x,
    _start_y,
    _end_x,
    _end_y
)
{
    var _distance =
        point_distance(
            _start_x,
            _start_y,
            _end_x,
            _end_y
        );

    var _spacing =
        max(
            2,
            _projectile.visual.radius * 0.5
        );

    var _steps =
        max(
            1,
            ceil(_distance / _spacing)
        );


    for (var i = 1; i <= _steps; ++i)
    {
        var _amount =
            i / _steps;

        var _check_x =
            lerp(
                _start_x,
                _end_x,
                _amount
            );

        var _check_y =
            lerp(
                _start_y,
                _end_y,
                _amount
            );

        var _cell =
            scr_building_position_to_cell(
                _check_x,
                _check_y
            );


        if (!scr_world_cell_inside(_cell.x, _cell.y))
        {
            return
            {
                hit: true,
                x: _check_x,
                y: _check_y
            };
        }


        if (
            scr_world_cell_type_get(
                _cell.x,
                _cell.y
            )
            == WorldCellType.DEAD
        )
        {
            return
            {
                hit: true,
                x: _check_x,
                y: _check_y
            };
        }
    }


    return
    {
        hit: false,
        x: _end_x,
        y: _end_y
    };
}